package Ex11;

import java.util.Scanner;

public class Animal {

    public static void main(String[] args) {

        Scanner ler = new Scanner(System.in);
        Cachorro c = new Cachorro();
        Papagaio p = new Papagaio();
        Mosca m = new Mosca();

        int indice = 1, indice2, indice3, indice4;

        while (indice != 0) {
            System.out.println("Crie um animal Frankenstein: \n"
                    + "1 - Cabeça\n"
                    + "2 - Tronco\n"
                    + "3 - Patas\n"
                    + "0 - Sair\n");
            indice = ler.nextInt();
            ler.nextLine();

            switch (indice) {
                case 1:
                    System.out.println("\nEscolha uma cabeça\n"
                            + "1 - cachorro\n"
                            + "2 - Papagaio\n"
                            + "3 - Mosca\n");
                    indice2 = ler.nextInt();
                    ler.nextLine();

                    switch (indice2) {
                        case 1:
                            System.out.println("Cabeça de Cachorro Adicionada!\n");
                            c.setCabeca("Cachorro");
                            break;
                        case 2:
                            System.out.println("Cabeça de Papagaio Adicionada!\n");
                            p.setCabeca("Papagaio");
                            break;
                        case 3:
                            System.out.println("Cabeça de Mosca Adicionada!\n");
                            m.setCabeca("Mosca");
                            break;
                    }
                    break;

                case 2:
                    System.out.println("\nEscolha um Tronco\n"
                            + "1 - cachorro\n"
                            + "2 - Papagaio\n"
                            + "3 - Mosca\n");
                    indice3 = ler.nextInt();
                    ler.nextLine();
                    switch (indice3) {
                        case 1:
                            System.out.println("Tronco de Cachorro Adicionada!\n");
                            c.setTronco("Cachorro");
                            break;
                        case 2:
                            System.out.println("Tronco de Papagaio Adicionada!\n");
                            p.setTronco("Papagaio");
                            break;
                        default:
                            System.out.println("Tronco de Mosca Adicionada!\n");
                            m.setTronco("Mosca");
                            break;
                    }
                    break;

                case 3:
                    System.out.println("\nEscolha as Patas\n"
                            + "1 - cachorro\n"
                            + "2 - Papagaio\n"
                            + "3 - Mosca\n");
                    indice4 = ler.nextInt();
                    ler.nextLine();
                    switch (indice4) {
                        case 1:
                            System.out.println("Patas de Cachorro Adicionada!\n");
                            c.setPatas("Cachorro");
                            break;
                        case 2:
                            System.out.println("Patas de Papagaio Adicionada!\n");
                            p.setPatas("Papagaio");
                            break;
                        default:
                            System.out.println("Patas de Mosca Adicionada!\n");
                            m.setPatas("Mosca");
                            break;
                    }
                    break;

                case 0:
                    indice = 0;
                    break;

                default:
                    System.out.println("Digite um valor Válido");

            }
        }

        

    }

}
