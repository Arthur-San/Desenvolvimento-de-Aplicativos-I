/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ex11;

public class Cachorro {
    private String cabeca, tronco, patas;

    public String getCabeca() {
        return cabeca;
    }
    public void setCabeca(String cabeca) {
        this.cabeca = cabeca;
    }

    public String getTronco() {
        return tronco;
    }
    public void setTronco(String tronco) {
        this.tronco = tronco;
    }

    public String getPatas() {
        return patas;
    }
    public void setPatas(String patas) {
        this.patas = patas;
    }
   

     
    
    
    

}
